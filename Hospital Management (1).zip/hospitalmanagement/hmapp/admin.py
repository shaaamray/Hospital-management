from django.contrib import admin
from .models import User, Appointment
from .models import Medicines, TempCart

class AdminMed(admin.ModelAdmin):
    list_display = ["name", "price"]

# Register your models here.
admin.site.register(User)
admin.site.register(Appointment)
admin.site.register(Medicines, AdminMed)
admin.site.register(TempCart)