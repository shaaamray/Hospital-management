from django.urls import path
from .views import *


urlpatterns = [
    path('', homePage, name='home'),

    path('patient-registration/', patientRegistration, name='patient-registration'),
    path('doctor-registration/', doctorRegistration, name='doctor-registration'),

    path('login/', loginPage, name='login'),
    path('logout/', logoutUser, name='logout'),

    path('dashboard', dasboardPage, name='dashboard'),

    path('book-appointment/<str:pk>', bookAppointment, name='book-appointment'),
    path('patient-appointments/', patientAppointments, name='patient-appointments'),
    path('patient-edit-appointment/<str:pk>', editAppointmentPatient, name='patient-edit-appointment'),
    path('patient-delete-appointment/<str:pk>', deleteAppointmentPatient, name='patient-delete-appointment'),

    path('doctor-dashboard/', doctorDashboard, name='doctor-dashboard'),
    path('patient-details/<str:pk>', doctorPatientView, name='view-patient'),
    path('patient-prescribe/<str:pk>', prescribePatient, name='prescribe-patient'),
    path('pharmacy/',Pharmacy, name= 'Pharmacy'),
    path('cart/<str:pk>/',Cart, name= 'cart'),
]
